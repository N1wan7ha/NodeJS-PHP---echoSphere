const express = require('express');
const Blog = require('../models/Blog');
const authMiddleware = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');
const mongoose = require('mongoose');

const router = express.Router();

// Get Logged-in User's Blog Posts - IMPORTANT: THIS MUST BE BEFORE ANY ROUTE WITH PARAMETERS
router.get('/myblogs', authMiddleware, async (req, res) => {
    try {
        console.log("==========================================");
        console.log("MYBLOGS ROUTE ACCESSED");
        console.log("REQ.USER:", req.user);
        
        // Debug token from request
        const authHeader = req.headers.authorization;
        console.log("AUTH HEADER:", authHeader ? `${authHeader.substring(0, 20)}...` : "None");
        
        // If we don't have a user from auth middleware, return error
        if (!req.user) {
            console.log("NO USER IN REQUEST - AUTH FAILURE");
            return res.status(401).json({ message: 'Not authenticated' });
        }
        
        // Normalize user ID (might be an object or a string)
        let userId = req.user;
        if (req.user._id) {
            userId = req.user._id;
        }
        console.log("USING USER ID:", userId);
        
        // Try fetching blogs
        try {
            // Use lean() for better performance
            const blogs = await Blog.find({ user: userId }).lean();
            console.log("BLOGS FOUND:", blogs ? blogs.length : 0);
            return res.json(blogs || []);
        } catch (dbError) {
            console.error("DATABASE ERROR:", dbError);
            return res.status(500).json({ message: 'Database error', details: dbError.message });
        }
    } catch (error) {
        console.error("==========================================");
        console.error("MYBLOGS ROUTE ERROR:", error);
        console.error("STACK:", error.stack);
        return res.status(500).json({ message: 'Server error', details: error.message });
    }
});

// Create Blog Post
router.post('/', authMiddleware, upload.single('image'), async (req, res) => {
    try {
        const { title, content } = req.body;
        const image = req.file ? req.file.filename : null;
        
        const userId = req.user._id || req.user;
        const blog = new Blog({ title, content, image, user: userId });
        
        await blog.save();
        res.status(201).json(blog);
    } catch (error) {
        console.error("CREATE BLOG ERROR:", error);
        res.status(500).json({ message: 'Server error', details: error.message });
    }
});

// Get All Blog Posts (Anyone can read)
router.get('/', async (req, res) => {
    try {
        const blogs = await Blog.find().populate('user', 'name email');
        res.json(blogs);
    } catch (error) {
        console.error("GET ALL BLOGS ERROR:", error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get Single Blog Post (Anyone can read)
router.get('/:id', async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id).populate('user', 'name email');
        if (!blog) return res.status(404).json({ message: 'Blog not found' });
        res.json(blog);
    } catch (error) {
        console.error("GET BLOG ERROR:", error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Update Blog Post
router.put('/:id', authMiddleware, upload.single('image'), async (req, res) => {
    try {
        const { title, content } = req.body;
        let blog = await Blog.findById(req.params.id);
        
        if (!blog) return res.status(404).json({ message: 'Blog not found' });

        // Normalize user IDs for comparison
        const userId = req.user._id || req.user;
        const blogUserId = blog.user._id || blog.user;
        
        // Check if the logged-in user is the owner of the blog
        if (blogUserId.toString() !== userId.toString()) {
            return res.status(403).json({ message: 'Not authorized to edit this blog' });
        }

        blog.title = title || blog.title;
        blog.content = content || blog.content;
        if (req.file) blog.image = req.file.filename;
        
        await blog.save();
        res.json(blog);
    } catch (error) {
        console.error("UPDATE BLOG ERROR:", error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete Blog Post
router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const blogId = req.params.id;

        if (!mongoose.Types.ObjectId.isValid(blogId)) {
            return res.status(400).json({ message: 'Invalid blog ID' });
        }

        const blog = await Blog.findById(blogId);
        if (!blog) return res.status(404).json({ message: 'Blog not found' });

        // Normalize user IDs for comparison
        const userId = req.user._id || req.user;
        const blogUserId = blog.user._id || blog.user;
        
        // Check ownership
        if (blogUserId.toString() !== userId.toString()) {
            return res.status(403).json({ message: 'Not authorized to delete this blog' });
        }

        await Blog.findByIdAndDelete(blogId);
        res.status(200).json({ message: 'Blog deleted successfully' });
    } catch (error) {
        console.error("DELETE BLOG ERROR:", error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;



// const express = require('express');
// const Blog = require('../models/Blog');
// const authMiddleware = require('../middleware/authMiddleware');
// const upload = require('../middleware/uploadMiddleware');
// const mongoose = require('mongoose');

// const router = express.Router();

// // Create Blog Post
// router.post('/', authMiddleware, upload.single('image'), async (req, res) => {
//     try {
//         const { title, content } = req.body;
//         const image = req.file ? req.file.filename : null;
//         const blog = new Blog({ title, content, image, user: req.user }); // Link the blog to the user
//         await blog.save();
//         res.status(201).json(blog);
//     } catch (error) {
//         res.status(500).json({ message: 'Server error' });
//     }
// });

// // Get All Blog Posts (Anyone can read)
// router.get('/', async (req, res) => {
//     try {
//         const blogs = await Blog.find().populate('user', 'name email');
//         res.json(blogs);
//     } catch (error) {
//         res.status(500).json({ message: 'Server error' });
//     }
// });

// // Get Single Blog Post (Anyone can read)
// router.get('/:id', async (req, res) => {
//     try {
//         const blog = await Blog.findById(req.params.id).populate('user', 'name email');
//         if (!blog) return res.status(404).json({ message: 'Blog not found' });
//         res.json(blog);
//     } catch (error) {
//         res.status(500).json({ message: 'Server error' });
//     }
// });

// // Update Blog Post (Only the user who created it can edit)
// router.put('/:id', authMiddleware, upload.single('image'), async (req, res) => {
//     try {
//         const { title, content } = req.body;
//         let blog = await Blog.findById(req.params.id);
//         if (!blog) return res.status(404).json({ message: 'Blog not found' });

//         // Check if the logged-in user is the owner of the blog
//         if (blog.user.toString() !== req.user.toString()) {
//             return res.status(403).json({ message: 'Not authorized to edit this blog' });
//         }

//         blog.title = title || blog.title;
//         blog.content = content || blog.content;
//         if (req.file) blog.image = req.file.filename; // Update the image if provided
//         await blog.save();

//         res.json(blog);
//     } catch (error) {
//         res.status(500).json({ message: 'Server error' });
//     }
// });

// // Delete Blog Post (Only the user who created it can delete)
// router.delete('/:id', authMiddleware, async (req, res) => {
//     try {
//         const blogId = req.params.id;

//         // Validate ObjectId
//         if (!mongoose.Types.ObjectId.isValid(blogId)) {
//             return res.status(400).json({ message: 'Invalid blog ID' });
//         }

//         const blog = await Blog.findById(blogId);
//         if (!blog) return res.status(404).json({ message: 'Blog not found' });

//         // Check if the logged-in user is the owner of the blog
//         if (blog.user.toString() !== req.user.toString()) {
//             return res.status(403).json({ message: 'Not authorized to delete this blog' });
//         }

//         await blog.remove();
//         res.status(200).json({ message: 'Blog deleted successfully' });
//     } catch (error) {
//         res.status(500).json({ message: 'Server error' });
//     }
// });


// // Get Logged-in User's Blog Posts (Dashboard Only)
// router.get('/myblogs', authMiddleware, async (req, res) => {
//     try {
//         console.log("=======================================");
//         console.log("MYBLOGS ROUTE ACCESSED");
//         console.log("REQ.USER:", JSON.stringify(req.user));
//         console.log("REQ.HEADERS:", JSON.stringify(req.headers));
        
//         let userId;
//         if (req.user && req.user._id) {
//             userId = req.user._id;
//         } else if (req.user) {
//             userId = req.user;
//         } else {
//             console.log("NO USER FOUND IN REQUEST");
//             return res.status(401).json({ message: 'User not authenticated' });
//         }
        
//         console.log("USING USER ID:", userId);
//         console.log("MONGOOSE CONNECTION STATE:", mongoose.connection.readyState);
        
//         // Try a simpler query first to test if Mongoose is working
//         const count = await Blog.countDocuments();
//         console.log("TOTAL BLOG COUNT IN DB:", count);
        
//         const blogs = await Blog.find({ user: userId });
//         console.log("BLOGS FOUND FOR USER:", blogs.length);
        
//         return res.json(blogs);
//     } catch (error) {
//         console.error("DETAILED ERROR:", error);
//         console.error("ERROR STACK:", error.stack);
//         return res.status(500).json({ message: 'Server error', details: error.message });
//     }
// });


// module.exports = router;
