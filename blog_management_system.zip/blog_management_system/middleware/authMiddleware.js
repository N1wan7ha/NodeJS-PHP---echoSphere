const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    try {
        console.log("AUTH MIDDLEWARE RUNNING");
        
        // Get token from header
        const authHeader = req.headers.authorization;
        console.log("AUTH HEADER RECEIVED:", authHeader ? `${authHeader.substring(0, 20)}...` : "None");
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            console.log("NO VALID AUTH HEADER");
            return res.status(401).json({ message: 'No token, authorization denied' });
        }
        
        const token = authHeader.replace('Bearer ', '');
        console.log("TOKEN EXTRACTED");
        
        try {
            // Verify token
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            console.log("TOKEN VERIFIED SUCCESSFULLY");
            console.log("DECODED TOKEN:", JSON.stringify(decoded));
            
            // Set user in request object
            if (decoded.userId) {
                req.user = decoded.userId;
            } else if (decoded.id) {
                req.user = decoded.id;
            } else {
                // If no recognized user ID format, use the whole payload
                req.user = decoded;
            }
            
            console.log("USER SET IN REQUEST:", req.user);
            next();
        } catch (jwtError) {
            console.error("JWT VERIFICATION ERROR:", jwtError);
            return res.status(401).json({ message: 'Token is not valid', details: jwtError.message });
        }
    } catch (error) {
        console.error("AUTH MIDDLEWARE ERROR:", error);
        return res.status(401).json({ message: 'Authentication failed', details: error.message });
    }
};


// const jwt = require('jsonwebtoken');
// const User = require('../models/User'); // Ensure this is correctly imported

// const authMiddleware = async (req, res, next) => {
//     const authHeader = req.header('Authorization');

//     if (!authHeader || !authHeader.startsWith('Bearer ')) {
//         return res.status(401).json({ message: 'No token provided or incorrect format' });
//     }

//     const token = authHeader.split(' ')[1]; // Extract token after "Bearer"

//     try {
//         const decoded = jwt.verify(token, process.env.JWT_SECRET);
//         console.log("Tk Decoded:", decoded);

//         // Fetch full user details from the database
//         const user = await User.findById(decoded.userId).select("-password");

//         if (!user) {
//             return res.status(401).json({ message: "User not found" });
//         }

//         req.user = user; // Attach full user object to request
//         next();
//     } catch (error) {
//         console.error("JWT Verification Error:", error.message);
//         return res.status(401).json({ message: 'Invalid or expired token' });
//     }
// };

// module.exports = authMiddleware;

