<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['token']) && !isset($_COOKIE['token'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EchoSphere - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .blog-card {
            transition: all 0.3s ease;
        }
        
        .blog-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .btn-action {
            transition: all 0.2s;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
        }
        
        .dashboard-title {
            background: linear-gradient(90deg, #4338ca,rgb(0, 0, 0));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .empty-state {
            border: 2px dashed #e2e8f0;
            transition: all 0.3s ease;
        }
        
        .empty-state:hover {
            border-color: #6366f1;
        }
        
        .loader {
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top: 4px solid #3498db;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            transform: translateX(120%);
            transition: transform 0.3s ease-out;
        }
        
        .toast-notification.show {
            transform: translateX(0);
        }
        
        .blog-table {
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .blog-table tr {
            transition: all 0.2s;
        }
        
        .blog-table tr:hover {
            background-color: #f8fafc;
        }
        
        .create-btn {
            position: relative;
            overflow: hidden;
        }
        
        .create-btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        
        .create-btn:hover::after {
            transform: translateX(0);
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Toast notification -->
    <div id="toast" class="toast-notification bg-green-50 border-l-4 border-green-500 text-green-700 hidden">
        <div class="flex items-center">
            <div class="mr-3">
                <i class="fas fa-check-circle text-xl"></i>
            </div>
            <div>
                <p id="toast-message" class="font-medium">Action completed successfully!</p>
            </div>
            <button onclick="hideToast()" class="ml-6 text-gray-400 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <!-- Navbar -->
    <nav class="bg-white border-gray-200 shadow-sm sticky top-0 z-50">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="index.php" class="flex items-center">
                <span class="font-bold text-2xl text-indigo-600">Echo</span><span class="text-gray-600">Sphere</span>
            </a>
            <div class="flex gap-3 items-center">
                <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-medium text-sm px-3 py-2 rounded-lg transition-colors">
                    <i class="fas fa-home mr-2"></i>Home
                </a>
                <!-- <a href="dashboard.php" class="text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg text-sm px-4 py-2 transition-colors">
                    <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                </a> -->
                <button onclick="logout()" class="text-white bg-red-600 hover:bg-red-700 font-medium rounded-lg text-sm px-4 py-2 transition-colors">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                </button>
            </div>
        </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="container mx-auto py-8 px-4">
        <!-- Dashboard Header -->
        <div class="flex flex-col md:flex-row justify-between items-center mb-8">
            <div>
                <h1 class="dashboard-title text-3xl font-bold mb-2">Blog Dashboard</h1>
                <p class="text-gray-600">Manage your blog posts and content</p>
            </div>
            <a href="create.php" class="create-btn bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg shadow-md mt-4 md:mt-0 inline-flex items-center transition-all">
                <i class="fas fa-plus-circle mr-2"></i>Create New Post
            </a>
        </div>
        
        <!-- Dashboard Stats -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
                <div class="flex items-center">
                    <div class="rounded-full bg-blue-100 p-3 mr-4">
                        <i class="fas fa-newspaper text-blue-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Total Posts</p>
                        <h3 id="totalPosts" class="text-2xl font-bold">-</h3>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
                <div class="flex items-center">
                    <div class="rounded-full bg-purple-100 p-3 mr-4">
                        <i class="fas fa-eye text-purple-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Recent Activity</p>
                        <h3 id="lastUpdated" class="text-2xl font-bold">-</h3>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
                <div class="flex items-center">
                    <div class="rounded-full bg-green-100 p-3 mr-4">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Status</p>
                        <h3 class="text-2xl font-bold text-green-600">Active</h3>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Blog Posts Table -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <div class="p-6 border-b border-gray-100">
                <h2 class="text-xl font-semibold text-gray-800">Your Blog Posts</h2>
                <p class="text-gray-500 text-sm mt-1">Manage and edit your published content</p>
            </div>
            
            <!-- Loading State -->
            <div id="loadingState" class="py-8">
                <div class="loader"></div>
                <p class="text-center text-gray-500 mt-4">Loading your blog posts...</p>
            </div>
            
            <!-- Empty State -->
            <div id="emptyState" class="py-12 px-6 text-center hidden">
                <div class="empty-state mx-auto max-w-md rounded-lg p-8">
                    <div class="rounded-full bg-gray-100 w-16 h-16 flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-newspaper text-gray-400 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-medium text-gray-800 mb-2">No blog posts yet</h3>
                    <p class="text-gray-600 mb-6">Get started by creating your first blog post</p>
                    <a href="create.php" class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg inline-flex items-center">
                        <i class="fas fa-plus mr-2"></i>Create Your First Post
                    </a>
                </div>
            </div>
            
            <!-- Table View -->
            <div id="tableView" class="hidden">
                <div class="overflow-x-auto">
                    <table class="blog-table min-w-full">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b">Title</th>
                                <th class="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b">Preview</th>
                                <th class="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b">Created</th>
                                <th class="py-3 px-6 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="blogList" class="divide-y divide-gray-100">
                            <!-- Blog list will be populated here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Delete Confirmation</h3>
            <p class="text-gray-600 mb-6">Are you sure you want to delete this blog post? This action cannot be undone.</p>
            <div class="flex justify-end gap-3">
                <button id="cancelDelete" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors">
                    Cancel
                </button>
                <button id="confirmDelete" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                    Delete
                </button>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>
    <script>
        // Global variables
        let blogIdToDelete = null;
        let blogs = [];
        
        // Format date helper function
        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric'
            });
        }
        
        // Format relative time helper function
        function timeAgo(dateString) {
            if (!dateString) return 'N/A';
            
            const date = new Date(dateString);
            const now = new Date();
            const diffMs = now - date;
            const diffSec = Math.floor(diffMs / 1000);
            
            if (diffSec < 60) return 'Just now';
            if (diffSec < 3600) return `${Math.floor(diffSec / 60)} minutes ago`;
            if (diffSec < 86400) return `${Math.floor(diffSec / 3600)} hours ago`;
            if (diffSec < 604800) return `${Math.floor(diffSec / 86400)} days ago`;
            
            return formatDate(dateString);
        }
        
        // Toast notification functions
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            // Set message and style based on type
            toastMessage.textContent = message;
            
            if (type === 'success') {
                toast.className = 'toast-notification bg-green-50 border-l-4 border-green-500 text-green-700';
                toast.querySelector('i').className = 'fas fa-check-circle text-xl';
            } else if (type === 'error') {
                toast.className = 'toast-notification bg-red-50 border-l-4 border-red-500 text-red-700';
                toast.querySelector('i').className = 'fas fa-exclamation-circle text-xl';
            }
            
            // Show toast
            toast.classList.remove('hidden');
            setTimeout(() => {
                toast.classList.add('show');
            }, 10);
            
            // Auto hide after 5 seconds
            setTimeout(hideToast, 5000);
        }
        
        function hideToast() {
            const toast = document.getElementById('toast');
            toast.classList.remove('show');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 300);
        }
        
        // Delete modal functions
        function openDeleteModal(id) {
            blogIdToDelete = id;
            document.getElementById('deleteModal').classList.remove('hidden');
        }
        
        function closeDeleteModal() {
            blogIdToDelete = null;
            document.getElementById('deleteModal').classList.add('hidden');
        }
        
        // Fetch blogs from API
        async function fetchBlogs() {
            console.log("Starting fetchBlogs function");
            
            // Show loading state
            document.getElementById('loadingState').classList.remove('hidden');
            document.getElementById('emptyState').classList.add('hidden');
            document.getElementById('tableView').classList.add('hidden');
            
            // Get token from localStorage
            const token = localStorage.getItem("token");
            console.log("Token from localStorage:", token ? "Token exists (not showing full token for security)" : "No token found");

            if (!token) {
                showToast("You are not logged in!", "error");
                setTimeout(() => {
                    window.location.href = "index.php";
                }, 2000);
                return;
            }

            try {
                console.log("Making fetch request to: http://localhost:5000/api/blogs/myblogs");
                
                const response = await fetch("http://localhost:5000/api/blogs/myblogs", {
                    method: "GET",
                    headers: { 
                        "Authorization": `Bearer ${token}`, 
                        "Content-Type": "application/json"
                    }
                });

                console.log("Response received, status:", response.status);
                
                const data = await response.json();
                console.log("Response data:", data);

                // Hide loading state
                document.getElementById('loadingState').classList.add('hidden');
                
                if (response.status !== 200) {
                    console.error("Error response:", data);
                    showToast(data.message || "Error fetching blogs", "error");
                    return;
                }

                if (!Array.isArray(data)) {
                    console.error("Expected an array but got:", data);
                    showToast("Error fetching blogs: Invalid data format", "error");
                    return;
                }
                
                // Save blogs globally
                blogs = data;
                
                // Update total posts count
                document.getElementById('totalPosts').textContent = data.length;
                
                // Show empty state if no blogs
                if (data.length === 0) {
                    document.getElementById('emptyState').classList.remove('hidden');
                    document.getElementById('tableView').classList.add('hidden');
                    return;
                }
                
                // Sort blogs by date (newest first)
                data.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
                
                // Update last updated time
                const latestBlog = data[0];
                document.getElementById('lastUpdated').textContent = latestBlog.createdAt ? 
                    timeAgo(latestBlog.createdAt) : 'N/A';
                
                // Show table view
                document.getElementById('tableView').classList.remove('hidden');
                
                // Render blogs
                let blogListHTML = "";
                data.forEach(blog => {
                    const truncatedTitle = blog.title.length > 40 ? 
                        blog.title.substring(0, 40) + '...' : blog.title;
                    
                    blogListHTML += `
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-6">
                                <div class="line-clamp-1 font-medium text-gray-900">${truncatedTitle}</div>
                            </td>
                            <td class="py-4 px-6">
                                <div class="flex items-center">
                                    <div class="h-16 w-16 rounded-md overflow-hidden bg-gray-100 mr-3 flex-shrink-0">
                                        <img src="${blog.image ? `http://localhost:5000/uploads/${blog.image}` : 'https://via.placeholder.com/150/f8fafc/a3a3a3?text=No+Image'}" 
                                             class="h-full w-full object-cover" alt="Blog thumbnail">
                                    </div>
                                    <p class="text-sm text-gray-500 line-clamp-2">${blog.content ? blog.content.substring(0, 80) + '...' : 'No content'}</p>
                                </div>
                            </td>
                            <td class="py-4 px-6">
                                <span class="text-sm text-gray-500">${blog.createdAt ? formatDate(blog.createdAt) : 'N/A'}</span>
                            </td>
                            <td class="py-4 px-6 text-center">
                                <div class="flex justify-center space-x-2">
                                    <a href="edit.php?id=${blog._id}" class="btn-action bg-indigo-100 text-indigo-700 hover:bg-indigo-200 font-medium py-2 px-3 rounded-lg text-sm inline-flex items-center">
                                        <i class="fas fa-edit mr-1"></i> Edit
                                    </a>
                                    <button onclick="openDeleteModal('${blog._id}')" class="btn-action bg-red-100 text-red-700 hover:bg-red-200 font-medium py-2 px-3 rounded-lg text-sm inline-flex items-center">
                                        <i class="fas fa-trash-alt mr-1"></i> Delete
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                });

                document.getElementById("blogList").innerHTML = blogListHTML;

            } catch (error) {
                console.error("Error in fetchBlogs function:", error);
                document.getElementById('loadingState').classList.add('hidden');
                showToast("Error fetching blogs: " + error.message, "error");
            }
        }     

        // Delete blog function
        async function deleteBlog() {
            if (!blogIdToDelete) return;
            
            const id = blogIdToDelete;
            closeDeleteModal();

            const token = localStorage.getItem("token");

            try {
                const response = await fetch(`http://localhost:5000/api/blogs/${id}`, {
                    method: "DELETE",
                    headers: { 
                        "Authorization": `Bearer ${token}`,
                        "Content-Type": "application/json"
                    }
                });

                const data = await response.json();

                if (response.ok) {
                    showToast("Blog deleted successfully!");
                    fetchBlogs();
                } else {
                    showToast(data.message || "Error deleting blog.", "error");
                }
            } catch (error) {
                console.error("Error deleting blog:", error);
                showToast("An error occurred while deleting the blog.", "error");
            }
        }

        // Logout function
        function logout() {
            localStorage.removeItem("token");
            sessionStorage.clear();
            document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            window.location.replace("index.php"); // Prevents back navigation
        }

        // Initialize event listeners
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('cancelDelete').addEventListener('click', closeDeleteModal);
            document.getElementById('confirmDelete').addEventListener('click', deleteBlog);
            
            // Initialize fetch blogs
            fetchBlogs();
        });
    </script>
</body>
</html>