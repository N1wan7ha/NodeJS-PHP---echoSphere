<?php
session_start();

// Redirect if not authenticated
if (!isset($_SESSION['token']) && !isset($_COOKIE['token'])) {
    die("Unauthorized access. Please log in.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Test Page</title>
</head>
<body>
    <h2>Testing API Response</h2>
    <pre id="responseBox">Fetching...</pre>

    <script>
        async function testAPI() {
            const token = localStorage.getItem("token");

            if (!token) {
                document.getElementById("responseBox").textContent = "Not logged in.";
                return;
            }

            try {
                const response = await fetch("http://localhost:5000/api/blogs/myblogs", {
                    headers: {
                        "Authorization": `Bearer ${token}`,
                        "Content-Type": "application/json"
                    }
                });

                const data = await response.json();
                console.log("API Response:", data); // Debugging

                if (response.ok) {
                    document.getElementById("responseBox").textContent = JSON.stringify(data, null, 2);
                } else {
                    document.getElementById("responseBox").textContent = `Error: ${data.message}`;
                }
            } catch (error) {
                console.error("Fetch error:", error);
                document.getElementById("responseBox").textContent = "Failed to connect to API.";
            }
        }

        testAPI();
    </script>
</body>
</html>
