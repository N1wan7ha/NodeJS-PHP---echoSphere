<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EchoSphere - Register</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gradient-to-r from-indigo-50 to-blue-50 min-h-screen">
    <nav class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="flex items-center">
                        <span class="font-bold text-2xl text-indigo-600">Echo</span><span class="text-gray-600">Sphere</span>
                    </a>
                </div>
                <!-- <div class="flex items-center">
                    <a href="register.php" class="text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 transition-all duration-300 ease-in-out">Register</a>
                    <a href="login.php" class="text-indigo-600 hover:text-indigo-800 font-medium mx-4">Login</a>
                </div> -->
            </div>
        </div>
    </nav>

    <div class="flex justify-center items-center px-4 py-12 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8 bg-white p-10 rounded-xl shadow-lg transform transition-all hover:shadow-xl">
            <div>
                <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">Create your account</h2>
                <p class="mt-2 text-center text-sm text-gray-600">
                    Join EchoSphere today
                </p>
            </div>
            <form id="registerForm" class="mt-8 space-y-6">
                <div class="rounded-md -space-y-px">
                    <div class="mb-4">
                        <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Full name</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-user text-gray-400"></i>
                            </div>
                            <input id="name" name="name" type="text" required class="appearance-none block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out sm:text-sm" placeholder="John Doe">
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email address</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input id="email" name="email" type="email" required class="appearance-none block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out sm:text-sm" placeholder="your@email.com">
                        </div>
                        <div id="emailValidationMessage" class="text-xs text-red-500 mt-1 hidden">Please enter a valid email address</div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input id="password" name="password" type="password" required class="appearance-none block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out sm:text-sm" placeholder="••••••••">
                            <div class="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer" id="togglePassword">
                                <i class="fas fa-eye text-gray-400 hover:text-gray-600"></i>
                            </div>
                        </div>
                        <div id="passwordStrength" class="mt-2">
                            <div class="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                                <div id="passwordStrengthBar" class="h-1 bg-red-500 transition-all duration-300 ease-in-out" style="width: 0%"></div>
                            </div>
                            <p id="passwordStrengthText" class="text-xs text-gray-500 mt-1">Password strength: Too weak</p>
                        </div>
                    </div>
                </div>

                <div class="flex items-center">
                    <input id="terms" name="terms" type="checkbox" required class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                    <label for="terms" class="ml-2 block text-sm text-gray-900">
                        I agree to the <a href="#" class="text-indigo-600 hover:text-indigo-500">Terms of Service</a> and <a href="#" class="text-indigo-600 hover:text-indigo-500">Privacy Policy</a>
                    </label>
                </div>

                <div>
                    <button type="submit" class="group relative w-full flex justify-center py-3 px-4 border border-transparent rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-300 ease-in-out transform hover:-translate-y-1">
                        <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                            <i class="fas fa-user-plus text-indigo-300 group-hover:text-indigo-200"></i>
                        </span>
                        Create account
                    </button>
                </div>

                <div class="text-center">
                    <p class="text-sm text-gray-600">
                        Already have an account? 
                        <a href="login.php" class="font-medium text-indigo-600 hover:text-indigo-500">
                            Sign in
                        </a>
                    </p>
                </div>

                <div id="statusMessage" class="mt-4 text-center hidden">
                    <div id="successMessage" class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg hidden"></div>
                    <div id="errorMessage" class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg hidden"></div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script>
        // Toggle password visibility
        document.getElementById("togglePassword").addEventListener("click", function() {
            const passwordInput = document.getElementById("password");
            const eyeIcon = this.querySelector("i");
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }
        });

        // Password strength checker
        document.getElementById("password").addEventListener("input", function() {
            const password = this.value;
            const strengthBar = document.getElementById("passwordStrengthBar");
            const strengthText = document.getElementById("passwordStrengthText");
            
            // Simple password strength calculation
            let strength = 0;
            
            if (password.length >= 8) strength += 25;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 25;
            if (password.match(/\d/)) strength += 25;
            if (password.match(/[^a-zA-Z\d]/)) strength += 25;
            
            // Update UI
            strengthBar.style.width = strength + "%";
            
            if (strength < 25) {
                strengthBar.className = "h-1 bg-red-500 transition-all duration-300 ease-in-out";
                strengthText.textContent = "Password strength: Too weak";
                strengthText.className = "text-xs text-red-500 mt-1";
            } else if (strength < 50) {
                strengthBar.className = "h-1 bg-orange-500 transition-all duration-300 ease-in-out";
                strengthText.textContent = "Password strength: Weak";
                strengthText.className = "text-xs text-orange-500 mt-1";
            } else if (strength < 75) {
                strengthBar.className = "h-1 bg-yellow-500 transition-all duration-300 ease-in-out";
                strengthText.textContent = "Password strength: Medium";
                strengthText.className = "text-xs text-yellow-600 mt-1";
            } else {
                strengthBar.className = "h-1 bg-green-500 transition-all duration-300 ease-in-out";
                strengthText.textContent = "Password strength: Strong";
                strengthText.className = "text-xs text-green-500 mt-1";
            }
        });

        // Email validation
        document.getElementById("email").addEventListener("blur", function() {
            const email = this.value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const validationMessage = document.getElementById("emailValidationMessage");
            
            if (email && !emailRegex.test(email)) {
                validationMessage.classList.remove("hidden");
                this.classList.add("border-red-500");
            } else {
                validationMessage.classList.add("hidden");
                this.classList.remove("border-red-500");
            }
        });

        // Register form submission
        document.getElementById("registerForm").addEventListener("submit", async function(event) {
            event.preventDefault();
            
            // Form validation
            const emailInput = document.getElementById("email");
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!emailRegex.test(emailInput.value)) {
                document.getElementById("emailValidationMessage").classList.remove("hidden");
                emailInput.classList.add("border-red-500");
                emailInput.focus();
                return;
            }
            
            // Show loading state
            const submitButton = this.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Creating account...';
            
            const name = document.getElementById("name").value;
            const email = emailInput.value;
            const password = document.getElementById("password").value;

            try {
                const response = await fetch("http://localhost:5000/api/auth/register", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ name, email, password })
                });

                const result = await response.json();
                
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
                
                // Show status message
                const statusMessage = document.getElementById("statusMessage");
                const successMessage = document.getElementById("successMessage");
                const errorMessage = document.getElementById("errorMessage");
                
                statusMessage.classList.remove("hidden");
                
                if (response.ok) {
                    successMessage.classList.remove("hidden");
                    errorMessage.classList.add("hidden");
                    successMessage.textContent = "Registration successful! Redirecting to login...";
                    
                    setTimeout(() => {
                        window.location.href = "login.php";
                    }, 2000);
                } else {
                    errorMessage.classList.remove("hidden");
                    successMessage.classList.add("hidden");
                    errorMessage.textContent = result.message || "Registration failed. Please try again.";
                }
            } catch (error) {
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
                
                // Show error message
                const statusMessage = document.getElementById("statusMessage");
                const errorMessage = document.getElementById("errorMessage");
                
                statusMessage.classList.remove("hidden");
                errorMessage.classList.remove("hidden");
                errorMessage.textContent = "Network error. Please try again later.";
            }
        });
    </script>
</body>
</html>