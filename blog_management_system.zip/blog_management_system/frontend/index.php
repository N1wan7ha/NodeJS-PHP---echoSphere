<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EchoSphere - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Common styles between pages */
        .echosphere-gradient {
            background: linear-gradient(90deg, #4338ca, #000000);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        /* Animations and transitions */
        .blog-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .blog-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .blog-tag {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
            border-radius: 999px;
            display: inline-block;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        /* Button animation */
        .animated-btn {
            position: relative;
            overflow: hidden;
        }
        
        .animated-btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        
        .animated-btn:hover::after {
            transform: translateX(0);
        }
        
        /* Read more button */
        .read-more-btn {
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
        }
        
        .read-more-btn:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: currentColor;
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.3s ease;
        }
        
        .read-more-btn:hover:after {
            transform: scaleX(1);
            transform-origin: left;
        }
        
        /* Modal styles */
        .blog-modal {
            display: none;
            position: fixed;
            z-index: 100;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            width: 85%;
            max-width: 800px;
            max-height: 85vh;
            overflow-y: auto;
            animation: modalFadeIn 0.3s ease-out;
        }
        
        @keyframes modalFadeIn {
            from {opacity: 0; transform: translateY(-20px);}
            to {opacity: 1; transform: translateY(0);}
        }
        
        .close-btn {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            transition: color 0.2s;
        }
        
        .close-btn:hover {
            color: #555;
            text-decoration: none;
            cursor: pointer;
        }
        
        /* Toast notification */
        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            transform: translateX(120%);
            transition: transform 0.3s ease-out;
        }
        
        .toast-notification.show {
            transform: translateX(0);
        }
        
        /* Loading animation */
        .loader {
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top: 4px solid #4338ca;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Skeleton loading styles */
        .skeleton {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
        }
        
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <!-- Toast notification -->
    <div id="toast" class="toast-notification bg-green-50 border-l-4 border-green-500 text-green-700 hidden">
        <div class="flex items-center">
            <div class="mr-3">
                <i class="fas fa-check-circle text-xl"></i>
            </div>
            <div>
                <p id="toast-message" class="font-medium">Action completed successfully!</p>
            </div>
            <button onclick="hideToast()" class="ml-6 text-gray-400 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <nav class="bg-white border-gray-200 dark:bg-gray-900 sticky top-0 z-50 shadow-md">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="index.php" class="flex items-center">
                <span class="font-bold text-2xl text-indigo-600">Echo</span><span class="text-gray-600">Sphere</span>
            </a>
            <div class="flex items-center md:order-2 space-x-2">
                <?php
                if (isset($_COOKIE['token'])) {
                    echo '<a href="dashboard.php" class="animated-btn text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm px-4 py-2 text-center transition-colors">
                        <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                    </a>';
                    echo '<button onclick="logout()" class="animated-btn text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-4 py-2 text-center transition-colors">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                    </button>';
                } else {
                    echo '<a href="login.php" class="animated-btn text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm px-4 py-2 text-center transition-colors">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>';
                }
                ?>
            </div>
        </div>
    </nav>

    <div class="container mx-auto mt-8 p-4">
        <h1 class="text-4xl font-bold mb-2 text-center echosphere-gradient">Latest Blog Posts</h1>
        <p class="text-center text-gray-600 mb-8">Discover our most recent stories and insights</p>
        
        <!-- Loading skeleton -->
        <div id="loadingSkeleton" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php for ($i = 0; $i < 6; $i++) { ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="skeleton h-48 w-full"></div>
                    <div class="p-5">
                        <div class="flex items-center text-gray-500 text-sm mb-2">
                            <div class="skeleton h-4 w-24 rounded-full"></div>
                        </div>
                        <div class="skeleton h-6 w-3/4 mb-3 rounded"></div>
                        <div class="skeleton h-4 w-full mb-2 rounded"></div>
                        <div class="skeleton h-4 w-2/3 mb-4 rounded"></div>
                        <div class="skeleton h-5 w-24 rounded"></div>
                    </div>
                </div>
            <?php } ?>
        </div>
        
        <!-- Error state -->
        <div id="errorState" class="hidden">
            <div class="flex flex-col items-center justify-center py-12">
                <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-4">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <span>Failed to load blog posts</span>
                </div>
                <button onclick="fetchBlogPosts()" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-sync-alt mr-2"></i>Try Again
                </button>
            </div>
        </div>
        
        <!-- Blog posts grid -->
        <div id="blogPosts" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 hidden">
            <!-- Blog posts will be loaded here -->
        </div>
        
        <!-- Empty state -->
        <div id="emptyState" class="hidden">
            <div class="text-center py-12">
                <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-newspaper text-gray-400 text-3xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">No blog posts yet</h3>
                <p class="text-gray-600">Check back later for new content</p>
            </div>
        </div>
    </div>
    
    <!-- Modal -->
    <div id="blogModal" class="blog-modal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <div id="modalContent">
                <!-- Blog post content will be displayed here -->
            </div>
        </div>
    </div>

    <footer class="bg-gray-800 text-white mt-12 py-8">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between">
                <div class="mb-6 md:mb-0">
                    <h3 class="text-xl font-bold mb-4">EchoSphere</h3>
                    <p class="text-gray-400">Sharing ideas that matter</p>
                </div>
                <div>
                    <h4 class="text-lg font-semibold mb-3">Connect With Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-twitter"></i> Twitter
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-facebook"></i> Facebook
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-instagram"></i> Instagram
                        </a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-6 text-center text-gray-500">
                <p>&copy; 2025 EchoSphere. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>
    <script>
        // Toast notification functions
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            // Set message and style based on type
            toastMessage.textContent = message;
            
            if (type === 'success') {
                toast.className = 'toast-notification bg-green-50 border-l-4 border-green-500 text-green-700';
                toast.querySelector('i').className = 'fas fa-check-circle text-xl';
            } else if (type === 'error') {
                toast.className = 'toast-notification bg-red-50 border-l-4 border-red-500 text-red-700';
                toast.querySelector('i').className = 'fas fa-exclamation-circle text-xl';
            }
            
            // Show toast
            toast.classList.remove('hidden');
            setTimeout(() => {
                toast.classList.add('show');
            }, 10);
            
            // Auto hide after 5 seconds
            setTimeout(hideToast, 5000);
        }
        
        function hideToast() {
            const toast = document.getElementById('toast');
            toast.classList.remove('show');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 300);
        }
        
        // Get modal elements
        const modal = document.getElementById("blogModal");
        const modalContent = document.getElementById("modalContent");
        const closeBtn = document.getElementsByClassName("close-btn")[0];
        
        // Close modal when clicking the close button
        closeBtn.onclick = function() {
            modal.style.display = "none";
            document.body.style.overflow = "auto"; // Re-enable scrolling
        }
        
        // Close modal when clicking outside the modal content
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
                document.body.style.overflow = "auto"; // Re-enable scrolling
            }
        }
        
        // Function to format date
        function formatDate(dateString) {
            const options = { year: 'numeric', month: 'long', day: 'numeric' };
            return new Date(dateString).toLocaleDateString(undefined, options);
        }
        
        // Function to calculate reading time
        function calculateReadingTime(text) {
            const wpm = 225; // Average reading speed
            const words = text.trim().split(/\s+/).length;
            const time = Math.ceil(words / wpm);
            return time < 1 ? '1 min read' : `${time} min read`;
        }
        
        async function fetchBlogPosts() {
            // Show loading skeletons, hide other states
            document.getElementById('loadingSkeleton').classList.remove('hidden');
            document.getElementById('blogPosts').classList.add('hidden');
            document.getElementById('errorState').classList.add('hidden');
            document.getElementById('emptyState').classList.add('hidden');
            
            try {
                const response = await fetch("http://localhost:5000/api/blogs");
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                
                const blogs = await response.json();
                
                // Hide loading skeleton
                document.getElementById('loadingSkeleton').classList.add('hidden');
                
                // Show empty state if no blogs
                if (!blogs || blogs.length === 0) {
                    document.getElementById('emptyState').classList.remove('hidden');
                    return;
                }
                
                // Sort blogs by date (newest first)
                blogs.sort((a, b) => new Date(b.createdAt || Date.now()) - new Date(a.createdAt || Date.now()));
                
                let blogPostsHTML = "";
                blogs.forEach(blog => {
                    // Generate random tags for demonstration
                    const tags = ["Technology", "Design", "News", "Tutorial", "Opinion"];
                    const randomTag = tags[Math.floor(Math.random() * tags.length)];
                    const tagColor = getTagColor(randomTag);
                    
                    // Format date or use placeholder
                    const displayDate = blog.createdAt ? formatDate(blog.createdAt) : "Recent";
                    
                    // Calculate reading time
                    const readingTime = blog.content ? calculateReadingTime(blog.content) : "1 min read";
                    
                    blogPostsHTML += `
                        <div class="blog-card bg-white rounded-lg shadow-md overflow-hidden">
                            <div class="relative">
                                <img src="http://localhost:5000/uploads/${blog.image}" alt="${blog.title}" class="w-full h-48 object-cover">
                                <div class="absolute top-3 right-3">
                                    <span class="blog-tag ${tagColor}">${randomTag}</span>
                                </div>
                            </div>
                            <div class="p-5">
                                <div class="flex items-center justify-between text-gray-500 text-sm mb-2">
                                    <div class="flex items-center">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <span>${displayDate}</span>
                                    </div>
                                    <div class="flex items-center">
                                        <i class="far fa-clock mr-1"></i>
                                        <span>${readingTime}</span>
                                    </div>
                                </div>
                                <h2 class="text-xl font-bold mb-3 text-gray-800 hover:text-indigo-600 transition-colors">${blog.title}</h2>
                                <p class="text-gray-600 mb-4 line-clamp-3">${blog.content ? blog.content.substring(0, 120) : ""}${blog.content && blog.content.length > 120 ? '...' : ''}</p>
                                <button class="read-more-btn text-indigo-600 font-medium hover:text-indigo-800 inline-flex items-center" 
                                        onclick='openBlogModal(${JSON.stringify(blog).replace(/"/g, '&quot;')})'>
                                    Read More
                                    <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    `;
                });
                
                document.getElementById("blogPosts").innerHTML = blogPostsHTML;
                document.getElementById("blogPosts").classList.remove('hidden');
            } catch (error) {
                console.error('Error fetching blogs:', error);
                document.getElementById('loadingSkeleton').classList.add('hidden');
                document.getElementById('errorState').classList.remove('hidden');
            }
        }
        
        function getTagColor(tag) {
            const tagColors = {
                "Technology": "bg-blue-100 text-blue-800",
                "Design": "bg-purple-100 text-purple-800",
                "News": "bg-green-100 text-green-800",
                "Tutorial": "bg-yellow-100 text-yellow-800",
                "Opinion": "bg-red-100 text-red-800"
            };
            
            return tagColors[tag] || "bg-gray-100 text-gray-800";
        }
        
        function openBlogModal(blog) {
            // Calculate reading time for modal
            const readingTime = blog.content ? calculateReadingTime(blog.content) : "1 min read";
            
            // Prepare modal content
            const modalHTML = `
                <div class="modal-header border-b pb-4 mb-6">
                    <h2 class="text-3xl font-bold text-gray-800">${blog.title}</h2>
                    <div class="flex items-center flex-wrap gap-3 mt-3 text-gray-500">
                        <span class="flex items-center">
                            <i class="far fa-calendar-alt mr-1"></i>
                            ${blog.createdAt ? formatDate(blog.createdAt) : "Recent"}
                        </span>
                        <span class="flex items-center">
                            <i class="far fa-user mr-1"></i>
                            ${blog.author || "EchoSphere Team"}
                        </span>
                        <span class="flex items-center">
                            <i class="far fa-clock mr-1"></i>
                            ${readingTime}
                        </span>
                    </div>
                </div>
                
                <div class="modal-image mb-6">
                    <img src="http://localhost:5000/uploads/${blog.image}" alt="${blog.title}" class="w-full h-auto max-h-96 object-cover rounded-lg shadow-sm">
                </div>
                
                <div class="modal-body prose max-w-none text-gray-700 leading-relaxed">
                    ${blog.content ? blog.content.split('\n').join('<br>') : "No content available."}
                </div>
                
                <div class="modal-footer mt-8 pt-4 border-t">
                    <div class="flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div>
                            <h4 class="text-sm uppercase text-gray-500 font-semibold">Share this post</h4>
                            <div class="flex space-x-3 mt-2">
                                <a href="#" class="text-blue-600 hover:text-blue-800 transition-colors">
                                    <i class="fab fa-twitter text-lg"></i>
                                </a>
                                <a href="#" class="text-blue-800 hover:text-blue-900 transition-colors">
                                    <i class="fab fa-facebook text-lg"></i>
                                </a>
                                <a href="#" class="text-red-500 hover:text-red-600 transition-colors">
                                    <i class="fab fa-pinterest text-lg"></i>
                                </a>
                                <a href="#" class="text-green-600 hover:text-green-700 transition-colors">
                                    <i class="far fa-envelope text-lg"></i>
                                </a>
                            </div>
                        </div>
                        <button id="closeModalBtn" class="animated-btn bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors">
                            <i class="fas fa-times mr-2"></i>Close
                        </button>
                    </div>
                </div>
            `;
            
            // Set modal content and display
            modalContent.innerHTML = modalHTML;
            modal.style.display = "block";
            document.body.style.overflow = "hidden"; // Prevent scrolling behind modal
            
            // Add event listener to the close button inside modal
            document.getElementById("closeModalBtn").addEventListener("click", function() {
                modal.style.display = "none";
                document.body.style.overflow = "auto"; // Re-enable scrolling
            });
        }
        
        function logout() {
            // Remove token from storage
            document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            localStorage.removeItem("token");
            
            // Show toast notification
            showToast("Logged out successfully");
            
            // Redirect after small delay
            setTimeout(() => {
                window.location.href = "index.php";
            }, 1000);
        }
        
        // Add escape key handler for modal
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && modal.style.display === 'block') {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
        
        // Load blog posts when page loads
        document.addEventListener('DOMContentLoaded', function() {
            fetchBlogPosts();
        });
    </script>
</body>
</html>