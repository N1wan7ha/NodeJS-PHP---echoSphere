<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EchoSphere - Create Blog</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white border-gray-200 shadow-sm sticky top-0 z-50">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="index.php" class="flex items-center">
                <span class="font-bold text-2xl text-indigo-600">Echo</span><span class="text-gray-600">Sphere</span>
            </a>
            <div class="flex gap-3 items-center">
                <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-medium text-sm px-3 py-2 rounded-lg transition-colors">
                    <i class="fas fa-home mr-2"></i>Home
                </a>
                <!-- <a href="dashboard.php" class="text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg text-sm px-4 py-2 transition-colors">
                    <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                </a> -->
                <button onclick="logout()" class="text-white bg-red-600 hover:bg-red-700 font-medium rounded-lg text-sm px-4 py-2 transition-colors">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                </button>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mx-auto mt-8 p-4 max-w-3xl">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-gray-800">Create New Blog</h2>
            <a href="dashboard.php" class="text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg text-sm px-4 py-2 transition-colors">
                    <i class="fas fa-tachometer-alt mr-2"></i>Back to Dashboard
                </a>
        </div>

        <div class="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <form id="createBlogForm" enctype="multipart/form-data">
                <div class="mb-5">
                    <label for="title" class="block text-gray-700 text-sm font-semibold mb-2">Title</label>
                    <input type="text" class="shadow-sm appearance-none border border-gray-300 rounded-lg w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out" id="title" placeholder="Enter your blog title" required>
                </div>
                
                <div class="mb-5">
                    <label for="content" class="block text-gray-700 text-sm font-semibold mb-2">Content</label>
                    <textarea class="shadow-sm appearance-none border border-gray-300 rounded-lg w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out" id="content" rows="8" placeholder="Write your blog content here..." required></textarea>
                    <div class="text-xs text-gray-500 mt-1">Rich text formatting will be applied automatically</div>
                </div>
                
                <div class="mb-6">
                    <label for="image" class="block text-gray-700 text-sm font-semibold mb-2">Featured Image</label>
                    <div class="flex items-center justify-center w-full">
                        <label for="image" class="flex flex-col items-center justify-center w-full h-40 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition duration-150 ease-in-out">
                            <div class="flex flex-col items-center justify-center pt-5 pb-6" id="uploadPlaceholder">
                                <i class="fas fa-cloud-upload-alt text-gray-400 text-3xl mb-3"></i>
                                <p class="mb-2 text-sm text-gray-500"><span class="font-semibold">Click to upload</span> or drag and drop</p>
                                <p class="text-xs text-gray-500">PNG, JPG or GIF (Max. 2MB)</p>
                            </div>
                            <div class="hidden flex-col items-center justify-center" id="previewContainer">
                                <img id="imagePreview" class="h-36 object-cover rounded" src="#" alt="Preview">
                            </div>
                            <input type="file" id="image" class="hidden" accept="image/*" onchange="previewImage(this)"/>
                        </label>
                    </div>
                </div>
                
                <div class="flex items-center justify-between">
                    <button type="button" onclick="window.location.href='dashboard.php'" class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4 focus:outline-none transition duration-150 ease-in-out">
                        Cancel
                    </button>
                    <button type="submit" id="submitBtn" class="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-6 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition duration-150 ease-in-out flex items-center">
                        <i class="fas fa-plus-circle mr-2"></i> Create Blog
                        <span id="loadingSpinner" class="hidden ml-2">
                            <i class="fas fa-spinner fa-spin"></i>
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="fixed bottom-5 right-5 hidden bg-white border border-gray-200 rounded-lg shadow-lg max-w-xs w-full p-4 text-gray-500 transition duration-300 transform translate-y-10 opacity-0">
        <div class="flex items-center">
            <div id="toastIcon" class="inline-flex items-center justify-center flex-shrink-0 w-8 h-8 rounded-lg"></div>
            <div class="ml-3 text-sm font-normal" id="toastMessage"></div>
            <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg p-1.5 inline-flex h-8 w-8" onclick="hideToast()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>
    <script>
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                    document.getElementById('uploadPlaceholder').classList.add('hidden');
                    document.getElementById('previewContainer').classList.remove('hidden');
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function showToast(message, type) {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            const toastIcon = document.getElementById('toastIcon');
            
            if (type === 'success') {
                toastIcon.className = 'inline-flex items-center justify-center flex-shrink-0 w-8 h-8 bg-green-100 text-green-500 rounded-lg';
                toastIcon.innerHTML = '<i class="fas fa-check"></i>';
            } else {
                toastIcon.className = 'inline-flex items-center justify-center flex-shrink-0 w-8 h-8 bg-red-100 text-red-500 rounded-lg';
                toastIcon.innerHTML = '<i class="fas fa-exclamation-circle"></i>';
            }
            
            toastMessage.textContent = message;
            toast.classList.remove('hidden', 'opacity-0', 'translate-y-10');
            toast.classList.add('opacity-100', 'translate-y-0');
            
            setTimeout(hideToast, 5000);
        }
        
        function hideToast() {
            const toast = document.getElementById('toast');
            toast.classList.add('opacity-0', 'translate-y-10');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 300);
        }

        document.getElementById("createBlogForm").addEventListener("submit", async function(event) {
            event.preventDefault();
            
            const submitBtn = document.getElementById('submitBtn');
            const loadingSpinner = document.getElementById('loadingSpinner');
            
            // Validate form
            const title = document.getElementById("title").value.trim();
            const content = document.getElementById("content").value.trim();
            
            if (!title) {
                showToast("Please enter a blog title", "error");
                return;
            }
            
            if (!content) {
                showToast("Please enter blog content", "error");
                return;
            }

            const token = localStorage.getItem("token");

            if (!token) {
                showToast("You are not logged in. Please log in first.", "error");
                setTimeout(() => {
                    window.location.href = "login.php";
                }, 2000);
                return;
            }

            // Show loading state
            submitBtn.disabled = true;
            loadingSpinner.classList.remove('hidden');

            const formData = new FormData();
            formData.append("title", title);
            formData.append("content", content);
            
            const imageInput = document.getElementById("image");
            if (imageInput.files[0]) {
                formData.append("image", imageInput.files[0]);
            }

            try {
                const response = await fetch("http://localhost:5000/api/blogs", {
                    method: "POST",
                    headers: { "Authorization": `Bearer ${token}` },
                    body: formData
                });

                // Reset loading state
                submitBtn.disabled = false;
                loadingSpinner.classList.add('hidden');

                if (!response.ok) {
                    const errorData = await response.json();
                    showToast(`Error: ${errorData.message}`, "error");
                    return;
                }

                showToast("Blog created successfully!", "success");
                setTimeout(() => {
                    window.location.href = "dashboard.php";
                }, 1500);
            } catch (error) {
                console.error("Error creating blog:", error);
                showToast("An error occurred. Please try again.", "error");
                
                // Reset loading state
                submitBtn.disabled = false;
                loadingSpinner.classList.add('hidden');
            }
        });

        function logout() {
            document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            localStorage.removeItem("token");
            showToast("You have been logged out", "success");
            setTimeout(() => {
                window.location.href = "index.php";
            }, 1000);
        }
    </script>
</body>
</html>